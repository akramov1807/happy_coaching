import React from 'react'
import { Button } from 'react-bootstrap'

export default function Btn({text}) {
  return (
    <Button className='Btn'>{text}</Button>
  )
}
